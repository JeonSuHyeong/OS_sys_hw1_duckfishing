#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct duck{
    char d_name[8];
    struct duck *nextDuck;
};

typedef struct duck Duck;
typedef Duck *DuckPtr;

//functions
void instructions();
void caution();
void fish_duck(DuckPtr *);
void release_duck(DuckPtr *);
int isEmpty(DuckPtr);
void show_ducks(DuckPtr);
void exit_program(DuckPtr);
void delay_fishing();

int main(){
    //initial value
    char name[8]; //string
    DuckPtr startPtr = NULL;
    int choice;
    int d_cnt = 0; //오리 수 세기

    //instructions
    instructions();
    scanf("%d", &choice);

    while(choice!=4){
        switch (choice){
            //오리를 잡을 때
            case 1:
                system("clear");
                if (d_cnt<10){
                    delay_fishing();
                    fish_duck(&startPtr);
                    show_ducks(startPtr);
                    d_cnt++;
                }
                //ASCII ART를 위한 배열이 10마리까지 잡을 수 있도록 배열을 설정하여 제한을 두었습니다.
                else{
                    printf("Too many ducks!\n");
                    printf("You can't fish more duck\n");
                    printf("Try another action\n\n");
                }
                break;
            //오리를 풀어줄 때
            case 2:
                system("clear");
                if (!isEmpty(startPtr)){
                    release_duck(&startPtr);
                    show_ducks(startPtr);
                    d_cnt--;
                    break;
                }
                //잡은 오리가 없을 때
                else{
                    caution();
                    break;
                }
            //잡은 오리를 보여줍니다.
            case 3:
                system("clear");
                if(!isEmpty(startPtr)){
                    show_ducks(startPtr);
                    break;
                }
                //잡은 오리가 없을 때
                else{
                    caution();
                    break;
                }
            //선택지에 없는 것을 고를때
            default:
                printf("Invaild choice.\n\n ");
                break;
        }
        instructions();
        scanf("%d", &choice);
    }
    exit_program(startPtr); //linked list에 저장된 것들을 모두 free합니다.
    printf("Quit the program!\n");
}   
    

void instructions(){
    printf("Enter your actions\n"
            "1 to fish a new duck\n"
            "2 to release the duck\n"
            "3 to show your duck\n"
            "4 to finish duckfishing\n");
}

void fish_duck(DuckPtr *sPtr){
    /*
    새로운 데이터에 malloc을 이용해 동적메모리를 할당한 뒤, 새로운 데이터와
    linked list에 저장된 데이터들을 headpointer부터 하나씩 strcmp함수를 이용해
    비교해가며 위치를 찾습니다.
    */
    DuckPtr newDuck, previousDuck, currentDuck;
    char name[8];
    int check_pos; // strcmp의 값을 반환받기 위한 변수

    printf("You fish a new duck!\n");
    printf("Name the duck(max 8) : ");
    scanf("%s", name);
    printf("\n");
    system("clear");
    
    //동적메모리 할당
    newDuck = malloc(sizeof(Duck));

    //memory가 충분한지 확인
    if(newDuck!=NULL){
        //initial value
        strcpy(newDuck->d_name, name); //d_name에 입력받은 이름을 저장합니다.(string)
        newDuck->nextDuck = NULL;
        previousDuck = NULL;
        currentDuck = *sPtr;

        //초기 checkpoint
        if(currentDuck==NULL){
            check_pos = 1;
        }
        else{
            //name과 currentDuck이 가르키는 주소의 d_name과 비교하여 ASCII값의 차이만큼 반환합니다.
            check_pos=strcmp(name, currentDuck->d_name);
        }

        //name과 d_name들을 비교하며 위치를 찾습니다.
        while (currentDuck !=NULL && check_pos>0){
            previousDuck = currentDuck;
            currentDuck = currentDuck->nextDuck;
            if(currentDuck!=NULL){
                //name과 currentDuck이 가르키는 주소의 d_name과 비교하여 ASCII값의 차이만큼 반환합니다.
                check_pos=strcmp(name, currentDuck->d_name);
            }
        }
        //위치가 linked list의 처음일 때
        if(previousDuck == NULL){
            newDuck->nextDuck = *sPtr; //first link the pointer
            *sPtr = newDuck; // change the head pointer
        }

        //else
        else{
            //previousDuck이 가르키는 nextDuck에 새로운 데이터의 주소 newDuck을 저장합니다.
            previousDuck->nextDuck =newDuck;
            //newDuck이 가르키는 nextDuck에 currentDuck를 저장합니다. 
            newDuck->nextDuck =currentDuck; 
        }
    }

    else{
        printf("%s not fished. No fishing line available\n",name);
    }

}

void release_duck(DuckPtr *sPtr){
    /*
    문자열을 비교해가며, 입력한 이름과 같은 이름을 찾습니다.
    이후 tempDuck에 임시로 currentDuck을 저장하고, previousDuck이 가르키는 nextDuck에
    currentDuck이 가르키는 nextDuck을 저장한 뒤, tempDuck에 저장된 주소를 free합니다.
    */
    DuckPtr tempDuck, previousDuck, currentDuck;
    char name[8];

    printf("Enter the name to release : ");
    scanf("%s", name);
    printf("\n");

    //입력받은 이름이 linked list에서 첫 번째에 위치할 때
    if (strcmp(name, (*sPtr)->d_name)==0){
        tempDuck = *sPtr; //tempDuck에 headpointer를 임시로 저장합니다.
        *sPtr = (*sPtr)->nextDuck; //sPtr에 새로운 headpointer를 저장합니다.
        free(tempDuck); //tempDuck에 저장된 headpointer를 free합니다.
    }

    else{
        //초기값 설정
        previousDuck = *sPtr;
        currentDuck = (*sPtr) -> nextDuck;

        //문자열을 비교해가며 일치할 때 까지 찾습니다.
        while(currentDuck!= NULL && strcmp(currentDuck->d_name,name) != 0){
            previousDuck = currentDuck;
            currentDuck = currentDuck->nextDuck;
        }
        //찾는 이름이 있을 때
        if(currentDuck!=NULL){
            tempDuck = currentDuck; //임시로 tempDuck에 currentDuck을 저장합니다.
            previousDuck->nextDuck = currentDuck->nextDuck;
            /*
            previousDuck이 가르키는 주소의 nextDuck에 currentDuck이 가르키는 주소의
            nextDuck을 저장합니다.
            */
            free(tempDuck); // tempDuck을 free합니다.
        }
        //찾는 이름이 없을 시
        else{
            printf("Invaild name.\n");
            printf("Try another action\n");
        }
        
    }
}

void show_ducks(DuckPtr sptr){
    char ASCII_P1[220]="";
    char ASCII_P2[220]="";
    char ASCII_P3[220]="";
    char ASCII_P4[220]="";
    char ASCII_P5[220]="";
    char ASCII_N6[220]="";
    char ASCII_N6_temp[25] = "                    ";
    int i,len;

    if (sptr == NULL){
        printf("Your fish line is empty");
    }

    else{
        printf("Here are the ducks you caught!\n");
        while (sptr !=NULL){
            strcat(ASCII_P1, "       ,~~.         ");
            strcat(ASCII_P2, "      (  6 )-_,     ");
            strcat(ASCII_P3, " (\\___ )=='-'   ->  ");
            strcat(ASCII_P4, "  \\ .   ) )         ");
            strcat(ASCII_P5, "   \\ `-' /          ");
            //이름을 달아줍니다.
            len =strlen(sptr->d_name);
            for (i=0;i<len;i++){
                ASCII_N6_temp[3+i] = sptr->d_name[i];
            }
            //
            strcat(ASCII_N6, ASCII_N6_temp);
            sptr = sptr->nextDuck;
            //초기화
            len = 0;
            strcpy(ASCII_N6_temp,"                    ");
        }

        printf("%s\n", ASCII_P1);
        printf("%s\n", ASCII_P2);
        printf("%s\n", ASCII_P3);
        printf("%s\n", ASCII_P4);
        printf("%s\n", ASCII_P5);
        printf("%s\n\n", ASCII_N6);
    }    
}

int isEmpty(DuckPtr sPtr){
    //structure pointer가 비어있을 때, NULL값을 반환합니다.
    return sPtr==NULL;
}

void caution(){
    //오리가 한마리도 없을 때
    printf("You don't have any ducks\n\n");
    printf("Try another action\n\n");
}

void exit_program(DuckPtr sPtr){
    /*
    headpointer를 입력받아, previousDuck에 임시로 currentDuck을 저장합니다.
    이후 currentDuck에 다음주소의 nextDuck을 저장한 뒤, previousDuck에 저장된
    주소를 free합니다.
    이를 currentDuck이 NULL이 될 때까지 반복합니다.
    */

    DuckPtr previousDuck, currentDuck;
    //초기값
    previousDuck = NULL;
    currentDuck = sPtr;
    
    while(!isEmpty(currentDuck)){
        previousDuck = currentDuck;
        currentDuck = currentDuck->nextDuck;
        free(previousDuck);
    }
}

void delay_fishing(){
    //낚시중을 표시
    char f_dot[11] = "fishing";
    int i, j;
    for(j=0;j<3;j++){
        system("clear");
        strcat(f_dot,".");
        printf("%s\n",f_dot);
        fflush(stdout);
        usleep(500000);
    }
    strcpy(f_dot,"fishing");
    system("clear");
}

